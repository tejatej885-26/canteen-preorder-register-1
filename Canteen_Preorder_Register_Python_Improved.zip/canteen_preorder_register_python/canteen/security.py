import hashlib
import hmac
import os
import re
from .database import connect

ITERATIONS = 240_000

def validate_text(value, field, maximum=100):
    value = str(value or "").strip()
    if not value:
        raise ValueError(f"{field} is required.")
    if len(value) > maximum:
        raise ValueError(f"{field} must be {maximum} characters or fewer.")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"{field} contains invalid control characters.")
    return value

def validate_email(email):
    email = validate_text(email, "Email", 150).lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ValueError("Enter a valid email address.")
    return email

def validate_phone(phone):
    phone = validate_text(phone, "Phone", 25)
    digits = re.sub(r"\D", "", phone)
    if not 7 <= len(digits) <= 15:
        raise ValueError("Phone number must contain 7 to 15 digits.")
    return phone

def hash_password(password, salt=None):
    if len(password) < 8:
        raise ValueError("Password must contain at least 8 characters.")
    salt = salt or os.urandom(16).hex()
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS
    ).hex()
    return digest, salt

def create_admin(username, password, db_path=None):
    username = validate_text(username, "Username", 40)
    password_hash, salt = hash_password(password)
    conn = connect(db_path)
    try:
        conn.execute(
            "INSERT INTO admins(username,password_hash,salt) VALUES(?,?,?)",
            (username, password_hash, salt)
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def authenticate(username, password, db_path=None):
    conn = connect(db_path)
    try:
        row = conn.execute(
            "SELECT password_hash,salt FROM admins WHERE username=?", (username,)
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return False
    candidate, _ = hash_password(password, row["salt"])
    return hmac.compare_digest(candidate, row["password_hash"])
