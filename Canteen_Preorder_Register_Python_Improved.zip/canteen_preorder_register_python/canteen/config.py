from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("CANTEEN_DATA_DIR", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "canteen.db"
REPORT_DIR = BASE_DIR / "reports"
