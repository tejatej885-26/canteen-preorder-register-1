from datetime import date
from .database import connect
from .security import validate_text, validate_email, validate_phone

STATUSES = {"Pending", "Confirmed", "Completed", "Cancelled"}

def add_preorder(customer_name, email, phone, item_name, quantity, unit_price,
                 notes="", db_path=None):
    name = validate_text(customer_name, "Customer name", 100)
    email = validate_email(email)
    phone = validate_phone(phone)
    item = validate_text(item_name, "Item name", 100)
    qty = int(quantity)
    price = float(unit_price)
    if qty < 1 or qty > 1000:
        raise ValueError("Quantity must be between 1 and 1000.")
    if price < 0:
        raise ValueError("Unit price cannot be negative.")
    if len(str(notes)) > 500:
        raise ValueError("Notes must be 500 characters or fewer.")
    conn = connect(db_path)
    try:
        cur = conn.execute("""INSERT INTO preorders
            (customer_name,email,phone,item_name,quantity,unit_price,notes)
            VALUES(?,?,?,?,?,?,?)""",
            (name, email, phone, item, qty, price, str(notes).strip()))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def list_preorders(db_path=None):
    conn = connect(db_path)
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM preorders ORDER BY order_date DESC,id DESC"
        ).fetchall()]
    finally:
        conn.close()

def update_preorder_status(order_id, status, db_path=None):
    if status not in STATUSES:
        raise ValueError(f"Status must be one of: {', '.join(sorted(STATUSES))}")
    conn = connect(db_path)
    try:
        cur = conn.execute("UPDATE preorders SET status=? WHERE id=?",
                           (status, int(order_id)))
        conn.commit()
        if cur.rowcount == 0:
            raise ValueError("Preorder ID was not found.")
    finally:
        conn.close()

def delete_preorder(order_id, db_path=None):
    conn = connect(db_path)
    try:
        cur = conn.execute("DELETE FROM preorders WHERE id=?", (int(order_id),))
        conn.commit()
        if cur.rowcount == 0:
            raise ValueError("Preorder ID was not found.")
    finally:
        conn.close()

def add_meal_plan(plan_name, meal_date, meal_type, item_name,
                  planned_quantity, price, notes="", db_path=None):
    plan = validate_text(plan_name, "Plan name", 100)
    try:
        date.fromisoformat(meal_date)
    except (TypeError, ValueError):
        raise ValueError("Meal date must use YYYY-MM-DD format.")
    kind = validate_text(meal_type, "Meal type", 30)
    item = validate_text(item_name, "Item name", 100)
    qty, amount = int(planned_quantity), float(price)
    if qty < 1 or amount < 0:
        raise ValueError("Planned quantity must be positive and price cannot be negative.")
    conn = connect(db_path)
    try:
        cur = conn.execute("""INSERT INTO meal_plans
          (plan_name,meal_date,meal_type,item_name,planned_quantity,price,notes)
          VALUES(?,?,?,?,?,?,?)""",
          (plan, meal_date, kind, item, qty, amount, str(notes).strip()))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def list_meal_plans(db_path=None):
    conn = connect(db_path)
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM meal_plans ORDER BY meal_date,id"
        ).fetchall()]
    finally:
        conn.close()

def add_pantry_item(item_name, quantity, unit, reorder_level=0, db_path=None):
    item = validate_text(item_name, "Pantry item", 100)
    unit = validate_text(unit, "Unit", 20)
    qty, level = float(quantity), float(reorder_level)
    if qty < 0 or level < 0:
        raise ValueError("Stock and reorder level cannot be negative.")
    conn = connect(db_path)
    try:
        cur = conn.execute("""INSERT INTO pantry(item_name,quantity,unit,reorder_level)
            VALUES(?,?,?,?)""", (item, qty, unit, level))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def update_pantry_stock(item_id, quantity, db_path=None):
    qty = float(quantity)
    if qty < 0:
        raise ValueError("Stock cannot be negative.")
    conn = connect(db_path)
    try:
        cur = conn.execute("""UPDATE pantry SET quantity=?,updated_at=CURRENT_TIMESTAMP
            WHERE id=?""", (qty, int(item_id)))
        conn.commit()
        if cur.rowcount == 0:
            raise ValueError("Pantry item ID was not found.")
    finally:
        conn.close()

def list_pantry(db_path=None):
    conn = connect(db_path)
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM pantry ORDER BY item_name"
        ).fetchall()]
    finally:
        conn.close()
