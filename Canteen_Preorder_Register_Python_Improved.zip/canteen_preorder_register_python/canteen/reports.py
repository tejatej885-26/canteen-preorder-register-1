import csv
from pathlib import Path
from .services import list_preorders
from .analytics import calculate_analytics

def export_csv(path="reports/preorders.csv", db_path=None):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    rows = list_preorders(db_path)
    fields = ["id","customer_name","email","phone","item_name","quantity",
              "unit_price","status","notes","order_date"]
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return target

def export_summary(path="reports/analytics_report.txt", db_path=None):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    s = calculate_analytics(db_path)
    lines = [
        "CANTEEN PREORDER REGISTER - ANALYTICS REPORT",
        "=" * 48,
        f"Total orders: {s['total_orders']}",
        f"Total quantity requested: {s['total_quantity']}",
        f"Revenue from non-cancelled orders: Rs. {s['total_revenue']:.2f}",
        f"Average order value: Rs. {s['average_order_value']:.2f}",
        f"Completion rate: {s['completion_rate']:.2f}%",
        f"Cancellation rate: {s['cancellation_rate']:.2f}%",
        "",
        "POPULAR ITEMS:"
    ]
    lines += [f"- {name}: {qty}" for name, qty in s["popular_items"]]
    lines += ["", "LOW STOCK ALERTS:"]
    lines += [f"- {x['item_name']}: {x['quantity']} {x['unit']} "
              f"(reorder at {x['reorder_level']})" for x in s["low_stock"]]
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target
