import argparse
import getpass
import sys
from .database import initialize_database
from .security import create_admin, authenticate
from .services import (
    add_preorder, list_preorders, update_preorder_status, delete_preorder,
    add_meal_plan, list_meal_plans, add_pantry_item, update_pantry_stock, list_pantry
)
from .analytics import calculate_analytics, create_charts
from .reports import export_csv, export_summary
from .config import DB_PATH, REPORT_DIR

def require_admin(username):
    password = getpass.getpass("Admin password: ")
    if not authenticate(username, password):
        print("Access denied: invalid username or password.")
        return False
    return True

def build_parser():
    parser = argparse.ArgumentParser(
        description="Canteen Preorder Register - Python CLI and analytics system"
    )
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("setup-admin", help="Create the first administrator account")
    p.add_argument("--username", required=True)
    sub.add_parser("add-order", help="Register a customer preorder")
    sub.add_parser("list-orders", help="Display all preorders")
    p = sub.add_parser("status", help="Change preorder status")
    p.add_argument("order_id", type=int)
    p.add_argument("value", choices=["Pending","Confirmed","Completed","Cancelled"])
    p = sub.add_parser("delete-order", help="Delete a preorder")
    p.add_argument("order_id", type=int)
    sub.add_parser("add-meal-plan", help="Create a meal plan")
    sub.add_parser("list-meal-plans", help="Display meal plans")
    sub.add_parser("add-pantry", help="Add a pantry item")
    sub.add_parser("list-pantry", help="Display pantry stock")
    p = sub.add_parser("stock", help="Update pantry stock quantity")
    p.add_argument("item_id", type=int)
    p.add_argument("quantity", type=float)
    sub.add_parser("analytics", help="Show analytical summary")
    sub.add_parser("charts", help="Generate Matplotlib charts")
    sub.add_parser("export", help="Export CSV and analytics report")
    return parser

def main(argv=None):
    initialize_database()
    args = build_parser().parse_args(argv)
    try:
        if args.command == "setup-admin":
            password = getpass.getpass("Create password (minimum 8 characters): ")
            confirm = getpass.getpass("Confirm password: ")
            if password != confirm:
                print("Passwords do not match.")
                return 1
            create_admin(args.username, password)
            print("Administrator account created.")
            return 0

        username = input("Admin username: ").strip()
        if not require_admin(username):
            return 1

        if args.command == "add-order":
            order_id = add_preorder(
                input("Customer name: "), input("Email: "), input("Phone: "),
                input("Item name: "), input("Quantity: "), input("Unit price (Rs.): "),
                input("Notes (optional): ")
            )
            print(f"Preorder registered successfully. ID: {order_id}")
        elif args.command == "list-orders":
            for row in list_preorders(): print(row)
        elif args.command == "status":
            update_preorder_status(args.order_id, args.value)
            print("Preorder status updated.")
        elif args.command == "delete-order":
            delete_preorder(args.order_id)
            print("Preorder deleted.")
        elif args.command == "add-meal-plan":
            new_id = add_meal_plan(
                input("Plan name: "), input("Date (YYYY-MM-DD): "),
                input("Meal type (Breakfast/Lunch/Snacks/Dinner): "),
                input("Item name: "), input("Planned quantity: "),
                input("Price (Rs.): "), input("Notes: ")
            )
            print(f"Meal plan created. ID: {new_id}")
        elif args.command == "list-meal-plans":
            for row in list_meal_plans(): print(row)
        elif args.command == "add-pantry":
            new_id = add_pantry_item(
                input("Item name: "), input("Quantity: "), input("Unit: "),
                input("Reorder level: ")
            )
            print(f"Pantry item created. ID: {new_id}")
        elif args.command == "list-pantry":
            for row in list_pantry(): print(row)
        elif args.command == "stock":
            update_pantry_stock(args.item_id, args.quantity)
            print("Stock quantity updated.")
        elif args.command == "analytics":
            for key, value in calculate_analytics().items(): print(f"{key}: {value}")
        elif args.command == "charts":
            print("Generated:", create_charts(db_path=DB_PATH, output_dir=REPORT_DIR))
        elif args.command == "export":
            print("CSV:", export_csv(db_path=DB_PATH))
            print("Summary:", export_summary(db_path=DB_PATH))
        return 0
    except (ValueError, TypeError) as exc:
        print(f"Error: {exc}")
        return 1
    except Exception as exc:
        print(f"Operation failed: {exc}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
