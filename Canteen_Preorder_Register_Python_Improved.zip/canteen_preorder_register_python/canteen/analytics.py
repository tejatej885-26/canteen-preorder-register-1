from collections import Counter
from .database import connect

def calculate_analytics(db_path=None):
    conn = connect(db_path)
    try:
        orders = conn.execute("SELECT * FROM preorders").fetchall()
        total_orders = len(orders)
        total_quantity = sum(row["quantity"] for row in orders)
        total_revenue = sum(row["quantity"] * row["unit_price"] for row in orders
                            if row["status"] != "Cancelled")
        completed = sum(1 for row in orders if row["status"] == "Completed")
        cancelled = sum(1 for row in orders if row["status"] == "Cancelled")
        average_order_value = (
            sum(row["quantity"] * row["unit_price"] for row in orders) / total_orders
            if total_orders else 0.0
        )
        completion_rate = completed / total_orders * 100 if total_orders else 0.0
        cancellation_rate = cancelled / total_orders * 100 if total_orders else 0.0
        popular = Counter()
        status_counts = Counter()
        for row in orders:
            popular[row["item_name"]] += row["quantity"]
            status_counts[row["status"]] += 1
        low_stock = conn.execute(
            "SELECT item_name,quantity,unit,reorder_level FROM pantry "
            "WHERE quantity <= reorder_level ORDER BY item_name"
        ).fetchall()
        return {
            "total_orders": total_orders,
            "total_quantity": total_quantity,
            "total_revenue": round(total_revenue, 2),
            "average_order_value": round(average_order_value, 2),
            "completion_rate": round(completion_rate, 2),
            "cancellation_rate": round(cancellation_rate, 2),
            "popular_items": popular.most_common(),
            "status_counts": dict(status_counts),
            "low_stock": [dict(row) for row in low_stock],
        }
    finally:
        conn.close()

def create_charts(db_path=None, output_dir="reports"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from pathlib import Path

    stats = calculate_analytics(db_path)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    statuses = stats["status_counts"]
    if statuses:
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.bar(list(statuses.keys()), list(statuses.values()))
        ax.set_title("Preorder Status Summary")
        ax.set_xlabel("Status")
        ax.set_ylabel("Number of orders")
        fig.tight_layout()
        fig.savefig(out / "order_status_chart.png", dpi=150)
        plt.close(fig)
    popular = stats["popular_items"][:8]
    if popular:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh([x[0] for x in popular][::-1], [x[1] for x in popular][::-1])
        ax.set_title("Most Requested Canteen Items")
        ax.set_xlabel("Quantity ordered")
        fig.tight_layout()
        fig.savefig(out / "popular_items_chart.png", dpi=150)
        plt.close(fig)
    return [str(p) for p in sorted(out.glob("*.png"))]
