# Canteen Preorder Register
**Version 2.0 — Python 3.10+ CLI application**

A Python command-line system for managing canteen preorders, meal plans and pantry inventory. It stores records in SQLite, calculates operational statistics, generates Matplotlib charts and exports reports.

## Main features
- Admin account setup and password verification (PBKDF2-HMAC-SHA256 with a random salt).
- Preorder create, list, status update and delete operations.
- MealPlan creation and listing.
- Pantry inventory management and low-stock alerts.
- Analytics: total orders, quantities, revenue excluding cancelled orders, average order value, completion rate, cancellation rate and popular items.
- Matplotlib charts for order status and popular items.
- CSV export and a text analytics report.
- Input validation, parameterized SQL queries and automated unit tests.

## Requirements
- Python 3.10 or later
- pip
- Matplotlib (installed from requirements.txt)

## Setup (Windows PowerShell)
```powershell
py -3 --version
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
```
If PowerShell blocks activation, use Command Prompt:
```bat
.venv\Scripts\activate.bat
```
Or run commands using `py app.py ...` without activating the environment after installing packages.

## First-time administrator setup
```powershell
py app.py setup-admin --username admin
```
Enter and confirm a password of at least 8 characters. Passwords are not stored as plain text.

## Commands
Every command except `setup-admin` asks for the administrator username and password.

```powershell
py app.py add-order
py app.py list-orders
py app.py status 1 Completed
py app.py delete-order 1
py app.py add-meal-plan
py app.py list-meal-plans
py app.py add-pantry
py app.py list-pantry
py app.py stock 1 12.5
py app.py analytics
py app.py charts
py app.py export
```

Interactive commands ask for the required fields. Dates for meal plans must use `YYYY-MM-DD`. Preorder statuses are `Pending`, `Confirmed`, `Completed` and `Cancelled`.

## Testing
Run the automated tests from the project directory:
```powershell
py -m unittest discover -s tests -v
```

## Output files
- `data/canteen.db` — SQLite database, created automatically.
- `reports/order_status_chart.png` — status chart, when data exists.
- `reports/popular_items_chart.png` — popular item chart, when data exists.
- `reports/preorders.csv` — preorder export.
- `reports/analytics_report.txt` — summary report.

## Database design
- `admins`: usernames and salted password hashes.
- `preorders`: customer details, item, quantity, price, status and timestamp.
- `meal_plans`: menu plan, date, meal type, item and planned quantity.
- `pantry`: stock quantity, unit and reorder threshold.

## Important notes
This is an academic/local CLI prototype. It does not process online payments, send SMS/email notifications, or provide a hosted web interface. Keep database backups and do not reuse personal passwords. The first administrator should be created by the project operator.

## Suggested demonstration
1. Create the administrator.
2. Add two preorders with different items and quantities.
3. List the orders and update one order to `Completed`.
4. Add a meal plan.
5. Add pantry stock with a reorder level.
6. Run analytics and generate charts.
7. Export the CSV and summary report.
8. Run the automated test suite.
