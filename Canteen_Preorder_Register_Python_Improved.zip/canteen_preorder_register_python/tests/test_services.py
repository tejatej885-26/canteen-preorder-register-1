import tempfile
import unittest
from pathlib import Path
from canteen.database import initialize_database
from canteen.services import (
    add_preorder, list_preorders, update_preorder_status, delete_preorder,
    add_meal_plan, list_meal_plans, add_pantry_item, update_pantry_stock, list_pantry
)
from canteen.analytics import calculate_analytics
from canteen.security import create_admin, authenticate

class CanteenTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = str(Path(self.tmp.name) / "test.db")
        initialize_database(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def test_preorder_create_update_delete(self):
        oid = add_preorder("Asha Rao", "asha@example.com", "9876543210",
                           "Veg Meal", 2, 60, db_path=self.db)
        self.assertEqual(len(list_preorders(self.db)), 1)
        update_preorder_status(oid, "Completed", self.db)
        self.assertEqual(list_preorders(self.db)[0]["status"], "Completed")
        delete_preorder(oid, self.db)
        self.assertEqual(list_preorders(self.db), [])

    def test_invalid_email_rejected(self):
        with self.assertRaises(ValueError):
            add_preorder("Asha", "wrong-email", "9876543210", "Meal", 1, 20,
                         db_path=self.db)

    def test_invalid_quantity_rejected(self):
        with self.assertRaises(ValueError):
            add_preorder("Asha", "a@b.com", "9876543210", "Meal", 0, 20,
                         db_path=self.db)

    def test_meal_plan(self):
        add_meal_plan("Monday Menu", "2026-11-30", "Lunch", "Rice Plate",
                      30, 55, db_path=self.db)
        self.assertEqual(len(list_meal_plans(self.db)), 1)

    def test_pantry_stock_and_low_stock(self):
        item = add_pantry_item("Rice", 3, "kg", 5, self.db)
        self.assertEqual(len(list_pantry(self.db)), 1)
        update_pantry_stock(item, 8, self.db)
        self.assertEqual(list_pantry(self.db)[0]["quantity"], 8)
        self.assertEqual(calculate_analytics(self.db)["low_stock"], [])

    def test_analytics_calculations(self):
        add_preorder("Asha", "a@b.com", "9876543210", "Idli", 2, 20,
                     db_path=self.db)
        add_preorder("Ravi", "r@b.com", "9876543211", "Dosa", 1, 40,
                     db_path=self.db)
        stats = calculate_analytics(self.db)
        self.assertEqual(stats["total_orders"], 2)
        self.assertEqual(stats["total_quantity"], 3)
        self.assertEqual(stats["total_revenue"], 80)
        self.assertEqual(stats["average_order_value"], 40)

    def test_admin_password_authentication(self):
        create_admin("admin", "securepass123", self.db)
        self.assertTrue(authenticate("admin", "securepass123", self.db))
        self.assertFalse(authenticate("admin", "wrongpass", self.db))

if __name__ == "__main__":
    unittest.main()
